
rootProject.name="keymanager-rest"
